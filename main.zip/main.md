# ATLANTIS. ТЕСТОВОЕ ЗАДАНИЕ DATA ANALYST
### Written by: Egor Bagaev

# Теоретическая часть

**Назовите ключевые метрики для оценки потенциала уже существующего игрового продукта**
- ROI - т.к. важно знать, как быстро окупятся вложенные деньги
- Retention - т.к. метрика показывает, сколько пользователей продолжает использовать продукт через определённый период времени, и напрямую влияет на пожизненную ценность клиента (LTV) и как следствие на ROI
**6 месяцев назад компания запустила новый продукт (мобильная игра) на рынок. Необходимо оценить примерный размер аудитории через следующие 6 месяцев. Какие данные вам понадобятся для оценки? Предложите способ оценки на основе этих данных.**

Количество новых пользователь, отток пользователей (churn). Пример оценки приведен по ссылке: [https://docs.google.com/spreadsheets/d/1eZc1MsE5di3yol6SL9IcQT2Ce-WF2_PSSXbT-HicQuA/edit#gid=0](https://docs.google.com/spreadsheets/d/1eZc1MsE5di3yol6SL9IcQT2Ce-WF2_PSSXbT-HicQuA/edit#gid=0) 

**Что такое LTV? Если у нас есть данные за первый месяц жизни приложения, как бы вы рассчитали LTV?**

LTV = это прибыль, которую средний пользователь принесет за все время использования продукта

С помощью когортного анализа

Взять когорту, посчитать прибыль в динамике по дням с момента регистрации, затем сосчитать суммарную прибыль от всей когорты пользователей в динамике по дням с момента регистрации, после сосчитать прибыль когорты пользователей в динамике по дням и наконец разделить прибыль на количество пользователей в когорте и получим динамику LTV когорты пользователей по дням, до 30 дней. Полученную прямую можно экстраполировать до нужного числа дней с помощь функции, например, логарифмической.

**Что такое ARPPU? В результате изменений в продукте ARPPU снизился. Это хорошо или плохо? Поясните ответ.**

ARPPU **-** средний доход, который приносит платящий пользователь

Зависит от случая

Хорошо - если количество платящих пользователей увеличилось (ARPPU при этом упал), т.к. доход увеличится

Плохо - когда количество платящих осталось на том же уровни (ARPPU при этом упал), т.к. доход тоже уменьшится

# Практическая часть


```python
import pandas as pd
import numpy as np
import sqlite3
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
path_to_db = 'E:/atlantis_test_task/test.db'
```


```python
with sqlite3.connect(path_to_db) as conn:
    profile_table =  pd.read_sql("SELECT * FROM profile", conn)
    level_up_table = pd.read_sql("SELECT * FROM level_up", conn)
    payment_table = pd.read_sql("SELECT * FROM payment", conn)
    quest_start_table = pd.read_sql("SELECT * FROM quest_start", conn)
    quest_complete_table = pd.read_sql("SELECT * FROM quest_complete", conn)
    session_close = pd.read_sql("SELECT * FROM session_close", conn)      
```


```python
dt_format = '%Y-%m-%d %H:%M:%S'
```


```python
# преобразуем нужные колонки в datetime
session_close['open_time'] = pd.to_datetime(pd.to_datetime(session_close['open_time']).dt.strftime(dt_format))
session_close['close_time'] = pd.to_datetime(pd.to_datetime(session_close['close_time']).dt.strftime(dt_format))
profile_table['reg_time'] = pd.to_datetime(pd.to_datetime(profile_table['reg_time']).dt.strftime(dt_format))
payment_table['time'] = pd.to_datetime(pd.to_datetime(payment_table['time']).dt.strftime(dt_format))
```

### Проверка соответствия периоду данных описанию задачи


```python
time_in_game = session_close.groupby('user_id').agg({'open_time':'min', 'close_time':'max'})
all_time_in_game = time_in_game['close_time'] - time_in_game['open_time']
```

## Анализ вовлеченности

 

### Median Session Lenght -  Средняя продолжительность сессии по игрокам


```python
duration = session_close.groupby(['user_id'])['duration']
duration.median().median()
```




    422.917



#### В среднем продолжительность сессии по игрокам составляет 422 секунд

### Cколько дней игрок был в игре


```python
session_close['open_date'] = session_close['open_time'].dt.date
days_in_game = session_close.groupby('user_id')['open_date'].nunique()
df_dg = pd.DataFrame(data=days_in_game.values, columns=['days_in_game'])
plt.figure(figsize=(16,9), dpi=100)
sns.set_style('whitegrid')
sns.countplot(x='days_in_game', data=df_dg, color='green').set(ylabel='count players', xlabel='days in game', title='Number of players by days in game')
```




    [Text(0, 0.5, 'count players'),
     Text(0.5, 0, 'days in game'),
     Text(0.5, 1.0, 'Number of players by days in game')]




    
![png](output_17_1.png)
    


### Session Count - Количество сессий


```python
session_count = session_close.groupby('user_id')['close_time'].count()
```

### Session Lenght - Время всех сессий


```python
all_time_sessions = session_close.groupby('user_id')['duration'].sum()
```

### DAU - Количество уникальных игроков, зашедших в игру хотя бы раз в день


```python
dau = session_close.groupby(pd.Grouper(key='open_time', freq='D'))['user_id'].nunique()
plt.figure(figsize=(16,9), dpi=100)
sns.set_style('whitegrid')
sns.lineplot(data=dau, x="open_time", y=dau.values).set(title="DAU", ylabel='count players', xlabel='date')
```




    [Text(0.5, 1.0, 'DAU'), Text(0, 0.5, 'count players'), Text(0.5, 0, 'date')]




    
![png](output_23_1.png)
    


#### Среднее количество уникальных игроков  по 3ем неделям


```python
dau_week.mean(level=0) # по неделям
```




    open_time
    2020-10-11    4110.285714
    2020-10-18    8527.571429
    2020-10-25    2397.333333
    Name: user_id, dtype: float64



### WAU - Количество уникальных игроков, зашедших в игру хотя бы раз в неделю


```python
wau = session_close.groupby(pd.Grouper(key='open_time', freq='W'))['user_id'].nunique()
plt.figure(figsize=(16,9), dpi=100)
sns.set_style('whitegrid')
sns.lineplot(data=wau, x="open_time", y=wau.values).set(title="WAU", ylabel='count players', xlabel='date')
wau
```




    open_time
    2020-10-11    21384
    2020-10-18    17926
    2020-10-25     6306
    Freq: W-SUN, Name: user_id, dtype: int64




    
![png](output_27_1.png)
    


### Sticky Factor - регулярно ли игроки заходят в игру


```python
dau_week = session_close.groupby([pd.Grouper(key='open_time', freq='W'),pd.Grouper(key='open_time', freq='D')])['user_id'].nunique().mean(level=0) # of week
sticky_factor = dau_week.mean(level=0)/wau
sticky_factor
```




    open_time
    2020-10-11    0.192213
    2020-10-18    0.475710
    2020-10-25    0.380167
    Name: user_id, dtype: float64



### Retention


```python
session_close = session_close.merge(profile_table[['user_id','reg_time']], how='left')
session_close['first_day'] = session_close['reg_time'].dt.date
# сколько времени прошло между регистрацией и сессией
session_close['delta_t'] = session_close['open_time'] - session_close['reg_time'] 
session_close['n_day'] = session_close['delta_t'].dt.days
# количество пользователей n-ого дня
count_n_day_users = session_close.groupby('n_day')['user_id'].nunique()
# надо убрать тех у кого не прошло n дней с момента регистрации
# дата актуальная (в реальном времени это сегодня) будет максимальная дата наблюдений, то есть максимальная close_time
report_date = session_close['close_time'].max()
# сколько дней прошло с момента регистрации
profile_table['days_since_reg'] = (report_date - profile_table['reg_time']).dt.days
retention = [count_n_day_users[nday] / profile_table.loc[profile_table['days_since_reg'] >= nday, 'user_id'].nunique() for nday in range(count_n_day_users.index.max())]
df_retention = pd.DataFrame(data=retention, columns=['retention'])
df_retention['days'] = df_retention.index
df_retention['retention'] = df_retention['retention'] * 100
plt.figure(figsize=(16,9), dpi=100)
sns.set_style('whitegrid')
sns.lineplot(data=df_retention, x="days", y="retention").set(title="Retention", ylabel='retention %')
print(retention)
```

    [0.9981359472923027, 0.38981198778724085, 0.3081471958862285, 0.26813434035031336, 0.23917724570143017, 0.21802988912100274, 0.20385666077454603, 0.19752530933633297, 0.185633938614816]
    


    
![png](output_31_1.png)
    


## Анализ монетизации

### Paying Share - Процент платящих игроков от общего количества игроков


```python
paying_players = payment_table['user_id'].nunique()
paying_share = paying_players / profile_table['user_id'].nunique()
format(paying_share, '0.00')
```




    '0.01'



### Gross Revenue - Общая сумма денег, которую заплатили игроки


```python
gross_revenue = payment_table['amount'].sum()
gross_revenue
```




    381.73969465648855



### ARPDAU (Average Revenue Per Daily Active User) - Доход за день / активных пользователей за день


```python
day_amount = payment_table.groupby(pd.Grouper(key='time', freq='D'))['amount'].sum()
arpdau = day_amount / dau
df_arpdau = pd.DataFrame(data=arpdau, columns=['value'])
plt.figure(figsize=(16,9), dpi=100)
sns.set_style('whitegrid')
sns.lineplot(data=arpdau, x=arpdau.index, y=arpdau.values).set(title="ARPDAU", xlabel='date', ylabel='revenue')
```




    [Text(0.5, 1.0, 'ARPDAU'), Text(0.5, 0, 'date'), Text(0, 0.5, 'revenue')]




    
![png](output_38_1.png)
    


### LTV


```python
payment_table = payment_table.merge(profile_table[['user_id','reg_time']], how='left')
payment_table['days_since_reg'] = (payment_table['time'] - payment_table['reg_time']).dt.days
amount_per_day = payment_table.groupby('days_since_reg').sum().cumsum()
ltv_pivot = payment_table.pivot_table(values='amount', index=pd.Grouper(key='reg_time', freq='D'), columns='days_since_reg', aggfunc='sum', fill_value=0).cumsum(axis=1)
reg_per_day = profile_table.groupby(pd.Grouper(key='reg_time', freq='D'))['user_id'].nunique()
reg_per_day.name = 'new_players'
ltv = ltv_pivot.div(reg_per_day,axis=0).mean(axis=0)
plt.figure(figsize=(16,9), dpi=100)
sns.set_style('whitegrid')
sns.lineplot(data=ltv, x=ltv.index, y=ltv.values).set(title="LTV", xlabel='days', ylabel='amount')
#plt.savefig('ltv.png')
```


    
![png](output_40_0.png)
    


## Вывовы

### 1. Средняя продолжительность игрового сеанса составляет 7.03 минут (422 секунды)
### 2. На 10 день в игру зашло 18% игроков
### 3. 1% игроков сконвертировалось в платящих
### 4. На 8 день был мощный приток пользователей, потом поток снизился и DAU упал
### 5. 9 и 23 октября наблюдается скачок ARPDAU
### 6. Наблюдается стабильный рост LTV, но неизвестно продолжится он дальше или остановится

## Дополненный список основных событий

#### 1. store_button_tracker(product_id(string), user_id(string)) - Отслеживание кнопок в магазине (ID товара, ID игрока) 
#### 2. discount_purchase(user_id(string), product_id(string), id_discount(string))- Покупка по скидке/активация промокода/игровому событию(ID игрока, ID товара/скидки, ID скидки/события) 
#### 3. place_the_game_close(user_id(string), time_close(timestamp), ID_place(string)) - В каком месте/на каком уровне игроки закрывают игру(ID игрока, время закрытия уровня, ID места/уровень)
#### 4. waste_resources(user_id(string), type_resource(string)) - Закончились ресурсы(ID игрока, тип ресурса(например, золото или кристаллы))
#### 5. tutorial_pass(user_id(string), progress(boolean)) - Прошел ли игрок обучение(ID игрока, прогресс прохождения)

## Стратегия дальнейшего анализа на основании предложенных событий

#### На основе предложенных событий посчитать следующее:
#### - Посчитать игроков, которые нажимали кнопку в магазин -> на товар в магазине/кнопку купить -> на отмену/выход из магазина (чтобы знать, что хотел купить игрок и что купил или не стал по каким-либо причинам покупать)
#### - Посчитать игроков, которые покупали что-либо по акции/скидке, участвовали в игровом событии (если такие имеются) (чтобы узнать, связаны ли скачки в рости ARPDAU с акциями или внутриигровыми событиями)
#### - Посчитать игроков, у которых закончились ресурсы и посмотреть на их дальйшие действия (вышли из игры, купили кристаллы, продолжили играть в игру и т.п.)
#### - Посчитать игроков, которые полностью закончили прохождение туториала (чтобы узнать, связано ли качество туториала на вовлеченность игрока, в частности с низкой продолжительностью сессии)
#### - Посчитать игроков, в каких местах в игре они чаще всего выходили, после какого события (чтобы узнать, связано ли то или иное событие/место с вовлеченностью игрока)
